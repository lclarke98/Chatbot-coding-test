Installation:
- 
- Unzip the file
- Run 'npm install'
- Run 'npm start'


Testing:
- 
All routes can be tested using postman by adding test data to
the body of the requests. Each time a message is sent the response will return the json
object will the full chat including a response from the 'bot'